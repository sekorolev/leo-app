# Security

The following describes our procedure for addressing major and minor security concerns in Leo.

### Reporting a Bug

During Testnet 3, all software bugs should be reported by filing a Github issue.

If you are unsure and would like to reach out to us directly, please email security \_at\_ aleo.org to elaborate on the issue.
