# Leo RFC xxx: Title

## Author(s)

## Summary

What is the proposal?

## Motivation

What problems does it solve? What is the background?

## Background (optional)

Information useful to understand the design.

## Design

What are the details of proposal?

## Drawbacks

What problems does this solution bring in?

## Effect on Ecosystem

How do the changes affect other projects and language ecosystem in general?

## Alternatives

What are the alternatives?

## Future Extensions (optional)

What are possible future extensions of the design?
