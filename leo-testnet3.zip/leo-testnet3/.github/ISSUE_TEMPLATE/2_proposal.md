---
name: 💥 Proposal
about: Propose a non-trivial change to Leo
title: "[Proposal]"
labels: 'proposal'
---

## 💥 Proposal

<!--
    What is your proposal for Leo?
    What are the implications of this proposal to Leo?
    Does your proposal affect other aspects of Aleo as well?
-->

(Write your proposal here)
