# token

## Run Guide

To run this program, run:
```bash
leo run mint <mint-inputs>
leo run transfer <transfer-inputs>  # update private key first
```

## Execute Guide

To execute this program, run:
```bash
leo execute mint <mint-inputs>
leo execute transfer <transfer-inputs>  # update private key first
```
