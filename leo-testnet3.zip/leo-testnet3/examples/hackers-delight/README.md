# Hacker's Delight

This directory contains a number of algorithms for counting trailing zeros as described in "Hacker's Delight, 2nd edition" by Henry S. Warren.
