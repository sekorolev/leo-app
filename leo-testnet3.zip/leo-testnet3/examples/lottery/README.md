# lottery.aleo

## Run Guide

To run this program, run:
```bash
leo run play <inputs>

or 

./run.sh
```

## Execute Guide

To execute this program, run:
```bash
leo execute play <inputs>
```
