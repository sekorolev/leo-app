# Leo message struct 
A basic example showing how to declare a struct in the Leo language.

## Run Guide

To run this program, run:
```bash
leo run main <inputs>
```

## Execute Guide

To execute this program, run:
```bash
leo execute main <inputs>
```
