# bubblesort

## Run Guide

To run this program, run:
```bash
leo run bubble_sort <inputs>
```

## Execute Guide

To execute this program, run:
```bash
leo execute bubble_sort <inputs>
```

## Overview

This example shows how to sort an array.

It takes the input data from inputs/bubblesort.in
