# src/twoadicity.leo

## Run Guide

To run this program, run:
```bash
leo run main <inputs>
```

## Execute Guide

To execute this program, run:
```bash
leo execute main <inputs>
```
